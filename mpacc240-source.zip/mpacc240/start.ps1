$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
$nodePath = if ($nodeCommand) { $nodeCommand.Source } else { $null }
if (-not $nodePath) {
  $runtimeRoot = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\runtimes\cua_node'
  if (Test-Path -LiteralPath $runtimeRoot) {
    $candidate = Get-ChildItem -LiteralPath $runtimeRoot -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($candidate) { $nodePath = $candidate.FullName }
  }
}
if (-not $nodePath) { throw 'Node.js was not found. Install Node.js 22 or newer, then run this launcher again.' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'dist\index.html'))) { throw 'The prebuilt dist folder is missing. Run npm install and npm run build first.' }
Write-Host 'Open: http://127.0.0.1:5173/'
& $nodePath (Join-Path $PSScriptRoot 'serve.cjs')
