// Serve the prebuilt app locally. No remote database or account is used.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const root = path.join(__dirname, 'dist');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' };
const server = http.createServer((req, res) => {
 try {
  const pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1:5173').pathname);
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); res.end('Not found'); return; }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(res);
 } catch { res.writeHead(400); res.end('Bad request'); }
});
server.on('error', error => { console.error(error.code === 'EADDRINUSE' ? 'Port 5173 is occupied. If the study room is already running, open http://127.0.0.1:5173/ . Otherwise stop the conflicting app first.' : error.message); process.exitCode = 1; });
server.listen(5173, '0.0.0.0', () => {
 console.log('Computer: http://127.0.0.1:5173/');
 for (const [name, addresses] of Object.entries(os.networkInterfaces())) {
  if (/tun|vpn|docker|wsl|vmware|virtualbox|loopback/i.test(name)) continue;
  for (const address of addresses || []) {
   if (address.family === 'IPv4' && !address.internal && !address.address.startsWith('169.254.')) {
    console.log(`iPad / phone on the same Wi-Fi (${name}): http://${address.address}:5173/`);
   }
  }
 }
 console.log('Keep this window and computer running. Press Ctrl+C to stop.');
});
