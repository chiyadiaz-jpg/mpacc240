import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './components/ui.css';
import './components/glass.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
