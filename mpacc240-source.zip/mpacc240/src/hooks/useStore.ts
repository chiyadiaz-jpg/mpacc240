import { useCallback, useEffect, useState } from 'react';
import type { State } from '../types';
import { loadState, saveState } from '../store/storage';
import { ensureDay } from '../services/planner';
import { today } from '../utils/date';
import { applyStudyProfile } from '../services/studyProfile';
export function useStore() {
    const [loaded] = useState(loadState);
    const [state, setState] = useState(() => ensureDay(applyStudyProfile(loaded.state, today()), today()));
    const [error, setError] = useState(loaded.error);
    const [blocked, setBlocked] = useState(!!loaded.error);
    const [saved, setSaved] = useState(true);
    useEffect(() => { if (blocked)
        return; try {
        saveState(state);
        setSaved(true);
    }
    catch {
        setSaved(false);
        setError('浏览器存储失败，请立即导出备份。');
    } }, [state, blocked]);
    useEffect(() => { const interval = setInterval(() => setState(s => ensureDay(s, today())), 30000); return () => clearInterval(interval); }, []);
    const update = useCallback((fn: (s: State) => State) => setState(s => fn(s)), []);
    const restore = useCallback((s: State) => { saveState(s); setBlocked(false); setError(null); setSaved(true); setState(ensureDay(s, today())); }, []);
    return { state, update, restore, error, saved, blocked };
}
