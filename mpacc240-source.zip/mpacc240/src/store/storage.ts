import type { State } from '../types';
import { initialState } from '../data/initial';
export const STORAGE_KEY = 'mpacc240-v1';
const object = (x: unknown): x is Record<string, unknown> => !!x && typeof x === 'object' && !Array.isArray(x);
const finite = (x: unknown, min: number, max: number) => typeof x === 'number' && Number.isFinite(x) && x >= min && x <= max;
const date = (x: unknown) => typeof x === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(x) && !Number.isNaN(Date.parse(x + 'T00:00:00')) && new Date(x + 'T00:00:00Z').toISOString().slice(0, 10) === x;
const string = (x: unknown) => typeof x === 'string' && x.length < 100000;
const subject = (x: unknown) => ['math', 'logic', 'writing', 'english'].includes(String(x));
const scores = (x: unknown, max = [75, 60, 65, 100]) => object(x) && ['math', 'logic', 'writing', 'english'].every((s, i) => finite(x[s], 0, max[i]));
const booleans = (o: Record<string, unknown>, keys: string[]) => keys.every(k => typeof o[k] === 'boolean');
export function validateBackup(value: unknown): State {
    const fail = () => { throw new Error('备份格式不正确，现有数据未被修改。'); };
    if (!object(value) || value.version !== 1 || !object(value.settings) || !object(value.days) || !Array.isArray(value.tasks) || !Array.isArray(value.modules) || !Array.isArray(value.sessions) || !Array.isArray(value.exams) || !Array.isArray(value.records) || !Array.isArray(value.phases))
        return fail();
    const s = value.settings;
    if (!date(s.examDate) || !date(s.startDate) || !finite(s.target, 1, 300) || !scores(s.targets) || !finite(s.dailyMinutes, 10, 1440) || !subject(s.weakest) || !object(s.progress) || !['light', 'dark'].includes(String(s.theme)) || typeof s.onboarded !== 'boolean' || !['math', 'logic', 'writing', 'english'].every(k => string((s.progress as Record<string, unknown>)[k])))
        return fail();
    for (const t of value.tasks) {
        if (!object(t) || !string(t.id) || !string(t.title) || !subject(t.subject) || !finite(t.minutes, 1, 600) || !date(t.created) || !date(t.due) || !finite(t.priority, -100, 100) || !finite(t.accuracy, 0, 100) || !['course', 'practice', 'essay', 'review', 'maintenance'].includes(String(t.kind)) || typeof t.debt !== 'boolean' || (t.doneDate !== undefined && !date(t.doneDate)))
            return fail();
    }
    if (new Set(value.tasks.map(t => t.id)).size !== value.tasks.length)
        return fail();
    for (const m of value.modules) {
        if (!object(m) || !string(m.id) || !string(m.title) || !subject(m.subject) || !['未开始', '一轮完成', '二轮进行中', '二轮完成', '专项训练', '真题验证', '基本掌握'].includes(String(m.status)) || !booleans(m, ['course', 'practice', 'verified']))
            return fail();
    }
    for (const e of value.exams) {
        if (!object(e) || !string(e.id) || !date(e.date) || !finite(e.total, 0, 300) || (e.scores !== null && !scores(e.scores)) || !scores(e.times, [300, 300, 300, 300]) || !object(e.errors) || !finite(e.errors.math, 0, 25) || !finite(e.errors.logic, 0, 30) || !finite(e.errors.english, 0, 20) || !Array.isArray(e.reasons) || !e.reasons.every(string) || typeof e.completed !== 'boolean' || !string(e.note))
            return fail();
        if (e.scores && Math.abs(Object.values(e.scores).reduce((a: number, b) => a + Number(b), 0) - Number(e.total)) > .001)
            return fail();
    }
    for (const r of value.records) {
        if (!object(r) || !string(r.id) || !subject(r.subject) || !date(r.date) || !finite(r.minutes, 0, 600) || !['title', 'type', 'cause', 'review', 'answer', 'structure', 'material', 'correction', 'reattempt'].every(k => string(r[k])) || !booleans(r, ['mastered', 'completed', 'knew', 'careless', 'overtime', 'hesitant']) || (r.accuracy !== undefined && !finite(r.accuracy, 0, 100)))
            return fail();
    }
    for (const x of value.sessions) {
        if (!object(x) || !string(x.id) || !string(x.taskId) || !string(x.title) || !subject(x.subject) || !date(x.date) || !finite(x.seconds, 0, 86400) || typeof x.completed !== 'boolean')
            return fail();
    }
    for (const [key, day] of Object.entries(value.days)) {
        if (!date(key) || !object(day) || !Array.isArray(day.tasks) || !day.tasks.every(string) || day.tasks.length > 3 || !object(day.limits) || !Object.values(day.limits).every(n => finite(n, 1, 600)) || !['standard', 'minimum', 'rescue', 'recovery'].includes(String(day.mode)) || !finite(day.budget, 0, 1440) || !object(day.review) || !['done', 'undone', 'problem', 'next'].every(k => string((day.review as Record<string, unknown>)[k])))
            return fail();
    }
    for (const p of value.phases) {
        if (!object(p) || !['id', 'title', 'focus'].every(k => string(p[k])) || !date(p.start) || !date(p.end) || String(p.start) > String(p.end))
            return fail();
    }
    if (value.focus !== null && (!object(value.focus) || !string(value.focus.taskId) || !finite(value.focus.target, 1, 600) || !finite(value.focus.elapsed, 0, 86400) || (value.focus.runningSince !== null && !finite(value.focus.runningSince, 0, 1e15))))
        return fail();
    const arrays = [value.tasks, value.modules, value.exams, value.records, value.sessions, value.phases];
    if (s.studyProfile !== undefined && s.studyProfile !== 'math-logic-v2') return fail();
    if (arrays.some(rows => rows.length > 30000 || new Set(rows.map(x => x.id)).size !== rows.length))
        return fail();
    const taskIds = new Set(value.tasks.map(x => x.id));
    if (Object.values(value.days).some(day => !object(day) || !(day.tasks as unknown[]).every(x => taskIds.has(x))))
        return fail();
    const focusId = object(value.focus) ? value.focus.taskId : null;
    if (focusId && (!taskIds.has(focusId) || value.tasks.find(t => t.id === focusId)?.deleted))
        return fail();
    for (const t of value.tasks) {
        if (['deleted', 'sample'].some(k => t[k] !== undefined && typeof t[k] !== 'boolean') || (t.moduleId !== undefined && !string(t.moduleId)))
            return fail();
    }
    for (const r of value.records) {
        if (r.reattempt && !date(r.reattempt) || (r.year !== undefined && !finite(r.year, 1990, 2099)) || (r.vocabulary !== undefined && !finite(r.vocabulary, 0, 1000)) || (r.sample !== undefined && typeof r.sample !== 'boolean'))
            return fail();
    }
    for (const x of value.sessions) {
        if (x.accuracy !== undefined && !finite(x.accuracy, 0, 100))
            return fail();
    }
    for (const day of Object.values(value.days)) {
        if (!object(day) || (day.accuracy !== undefined && !finite(day.accuracy, 0, 100)))
            return fail();
    }
    return structuredClone(value) as unknown as State;
}
export function loadState(): {
    state: State;
    error: string | null;
} { try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return { state: raw ? validateBackup(JSON.parse(raw)) : initialState(), error: null };
}
catch {
    return { state: initialState(), error: '已有存档无法读取。原存档已保留，请先下载原始存档再恢复备份。' };
} }
export function saveState(s: State) { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); }
