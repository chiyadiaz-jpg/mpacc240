export type Subject = 'math' | 'logic' | 'writing' | 'english';
export type Status = '未开始' | '一轮完成' | '二轮进行中' | '二轮完成' | '专项训练' | '真题验证' | '基本掌握';
export interface Settings {
    examDate: string;
    startDate: string;
    target: number;
    targets: Record<Subject, number>;
    dailyMinutes: number;
    weakest: Subject;
    progress: Record<Subject, string>;
    theme: 'light' | 'dark';
    onboarded: boolean;
    studyProfile?: 'math-logic-v2';
}
export interface Task {
    id: string;
    title: string;
    subject: Subject;
    minutes: number;
    created: string;
    due: string;
    priority: number;
    kind: 'course' | 'practice' | 'essay' | 'review' | 'maintenance';
    moduleId?: string;
    debt: boolean;
    accuracy: number;
    doneDate?: string;
    deleted?: boolean;
    sample?: boolean;
}
export interface Module {
    id: string;
    subject: Subject;
    title: string;
    status: Status;
    course: boolean;
    practice: boolean;
    verified: boolean;
}
export interface Session {
    id: string;
    taskId: string;
    title: string;
    subject: Subject;
    date: string;
    seconds: number;
    completed: boolean;
    accuracy?: number;
}
export interface Exam {
    id: string;
    date: string;
    scores: Record<Subject, number> | null;
    total: number;
    times: Record<Subject, number>;
    errors: {
        math: number;
        logic: number;
        english: number;
    };
    reasons: string[];
    completed: boolean;
    note: string;
    sample?: boolean;
}
export interface StudyRecord {
    id: string;
    subject: Subject;
    date: string;
    title: string;
    type: string;
    minutes: number;
    accuracy?: number;
    vocabulary?: number;
    year?: number;
    cause: string;
    review: string;
    answer: string;
    structure: string;
    material: string;
    correction: string;
    reattempt: string;
    mastered: boolean;
    completed: boolean;
    knew: boolean;
    careless: boolean;
    overtime: boolean;
    hesitant: boolean;
    sample?: boolean;
}
export interface Day {
    tasks: string[];
    mode: 'standard' | 'minimum' | 'rescue' | 'recovery';
    limits: Record<string, number>;
    budget: number;
    review: {
        done: string;
        undone: string;
        problem: string;
        next: string;
    };
    accuracy?: number;
}
export interface Phase {
    id: string;
    title: string;
    start: string;
    end: string;
    focus: string;
}
export interface Focus {
    taskId: string;
    target: number;
    elapsed: number;
    runningSince: number | null;
}
export interface State {
    version: 1;
    settings: Settings;
    tasks: Task[];
    modules: Module[];
    exams: Exam[];
    sessions: Session[];
    records: StudyRecord[];
    days: Record<string, Day>;
    phases: Phase[];
    focus: Focus | null;
}
