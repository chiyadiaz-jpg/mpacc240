import { useState, useRef } from 'react';
import type { State, Settings, Subject } from '../types';
import { subjects, maxima, initialState } from '../data/initial';
import { validateBackup, STORAGE_KEY } from '../store/storage';
import { Download, Upload, ShieldCheck, Trash2, Sun, Moon } from 'lucide-react';
import { Modal } from '../components/Modal';
import { today } from '../utils/date';
export function SettingsForm({ value, onSave, onboarding = false }: {
    value: Settings;
    onSave: (s: Settings) => void;
    onboarding?: boolean;
}) { const [s, set] = useState(value); return <form onSubmit={e => { e.preventDefault(); onSave({ ...s, onboarded: true }); }}><p>{onboarding ? '已经填好你的备考情况。确认日期，就可以开始。' : '修改后会更新倒计时、分数目标和后续排程。'}</p><div className="form-grid"><label>考试日期<input type="date" required value={s.examDate} onChange={e => set({ ...s, examDate: e.target.value })}/><small>默认 2026-12-19 是占位日期，请按实际安排确认。</small></label><label>开始备考日期<input type="date" required max={today()} value={s.startDate} onChange={e => set({ ...s, startDate: e.target.value })}/></label><label>目标总分<input type="number" required min={1} max={300} value={s.target} onChange={e => set({ ...s, target: Number(e.target.value) })}/></label><label>每天可学习分钟<input type="number" required min={10} max={1440} value={s.dailyMinutes} onChange={e => set({ ...s, dailyMinutes: Number(e.target.value) })}/></label></div><div className="form-grid">{Object.entries(subjects).map(([key, label]) => <label key={key}>{label}目标 / {maxima[key as Subject]}<input type="number" required min={0} max={maxima[key as Subject]} value={s.targets[key as Subject]} onChange={e => set({ ...s, targets: { ...s.targets, [key]: Number(e.target.value) } })}/></label>)}</div>{Object.values(s.targets).reduce((a, b) => a + b, 0) !== s.target && <p className="warning">分科目标合计 {Object.values(s.targets).reduce((a, b) => a + b, 0)} 分，与总目标不同；可作为弹性目标保留。</p>}<label>目前最薄弱科目<select value={s.weakest} onChange={e => set({ ...s, weakest: e.target.value as Subject })}>{Object.entries(subjects).map(([v, l]) => <option value={v} key={v}>{l}</option>)}</select></label><details className="details"><summary>各科当前进度 · 可修改</summary>{Object.entries(subjects).map(([key, label]) => <label key={key}>{label}<input value={s.progress[key as Subject]} required onChange={e => set({ ...s, progress: { ...s.progress, [key]: e.target.value } })}/></label>)}</details><div className="form-actions"><button className="primary large">{onboarding ? '确认，开始我的备考' : '保存设置'}</button></div></form>; }
export function SettingsPage({ state, update, restore, notify, blocked }: {
    state: State;
    update: (f: (s: State) => State) => void;
    restore: (s: State) => void;
    notify: (m: string) => void;
    blocked: boolean;
}) { const file = useRef<HTMLInputElement>(null); const [pending, setPending] = useState<State | null>(null); const [clear, setClear] = useState(false); const download = (value: string, name: string) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([value], { type: 'application/json' })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }; return <><div className="two-cols"><section className="card"><h2>让计划适合你</h2><SettingsForm value={state.settings} onSave={settings => { update(s => ({ ...s, settings })); notify('设置已保存'); }}/></section><div className="stack"><section className="card"><div className="panel-title"><ShieldCheck size={19}/><h2>数据只保存在你的浏览器</h2></div><p>刷新和重新打开会保留记录。不同设备、浏览器或端口之间不会自动同步；搬家时请导出并导入备份。</p><button className="secondary full" onClick={() => download(JSON.stringify(state, null, 2), `mpacc240-${today()}.json`)}><Download size={16}/>导出全部数据</button><button className="secondary full" onClick={() => file.current?.click()}><Upload size={16}/>导入备份</button><input ref={file} type="file" accept=".json,application/json" hidden onChange={async (e) => { try {
    const f = e.target.files?.[0];
    if (!f)
        return;
    if (f.size > 10 * 1024 * 1024)
        throw new Error('备份超过 10MB，请检查文件。');
    setPending(validateBackup(JSON.parse(await f.text())));
}
catch (err) {
    notify(err instanceof Error ? err.message : '导入失败');
} e.target.value = ''; }}/>{blocked && <button className="secondary full" onClick={() => download(localStorage.getItem(STORAGE_KEY) ?? '', 'mpacc240-original.json')}>下载无法读取的原始存档</button>}<small>建议每周备份一次，清理浏览器数据前先导出。</small></section><section className="card"><h2>外观</h2><div className="segmented"><button className={state.settings.theme === 'light' ? 'selected' : ''} onClick={() => update(s => ({ ...s, settings: { ...s.settings, theme: 'light' } }))}><Sun size={16}/>浅色</button><button className={state.settings.theme === 'dark' ? 'selected' : ''} onClick={() => update(s => ({ ...s, settings: { ...s.settings, theme: 'dark' } }))}><Moon size={16}/>深色</button></div></section><section className="card"><h2>整理数据</h2><p>示例只有一条数学错题。你提供的 205 分是个人基线，清除示例不会删除它。</p><button className="secondary full" onClick={() => { update(s => ({ ...s, tasks: s.tasks.filter(x => !x.sample), records: s.records.filter(x => !x.sample), exams: s.exams.filter(x => !x.sample) })); notify('示例数据已清除'); }}>清除示例数据</button><button className="danger full" onClick={() => setClear(true)}><Trash2 size={14}/>清空学习记录</button></section></div></div>{pending && <Modal title="确认恢复备份" onClose={() => setPending(null)}><p>备份包含 {pending.tasks.length} 项任务、{pending.exams.length} 次模考、{pending.records.length} 条训练记录。恢复会替换当前全部数据。</p><p>如果当前记录还需要保留，请先导出。</p><div className="form-actions"><button className="secondary" onClick={() => setPending(null)}>取消</button><button className="primary" onClick={() => { try {
    restore(pending);
    setPending(null);
    notify('备份已恢复');
}
catch {
    notify('存储空间不足，无法恢复；原记录未改变。');
} }}>确认恢复</button></div></Modal>}{clear && <Modal title="清空学习记录？" onClose={() => setClear(false)}><p>将清空任务、模考、训练、专注和复盘记录，保留个人设置、备考地图和阶段计划。此操作可以通过事先导出的备份恢复。</p><div className="form-actions"><button className="secondary" onClick={() => setClear(false)}>取消</button><button className="danger" onClick={() => { const empty = initialState(); empty.settings = state.settings; empty.modules = state.modules; empty.phases = state.phases; empty.tasks = []; empty.exams = []; empty.records = []; try {
    restore(empty);
    setClear(false);
    notify('学习记录已清空');
}
catch {
    notify('清空失败，原数据未改变');
} }}>确认清空</button></div></Modal>}</>; }
