import { ArrowRight, Brain, Calculator, CalendarDays, Check, CheckCircle2, ChevronRight, Clock3, Flame, GraduationCap, HelpCircle, Layers3, Pencil, PenLine, Play, Plus, Sparkles, Target } from 'lucide-react';
import type { State, Subject, Task } from '../types';
import { subjects, maxima } from '../data/initial';
import { today, daysBetween, formatMinutes } from '../utils/date';
import { completion, minutesOn, sortedExams, weekStats } from '../utils/statistics';
import { rankedTasks } from '../services/priority';
import { TimeChart } from '../components/Charts';
import { Review } from './CalendarPage';

interface Props {
    state: State;
    update: (fn: (state: State) => State) => void;
    onPage: (page: 'plan'|'map'|'math'|'logic'|'writing'|'english'|'exams'|'settings') => void;
    onStart: (task: Task, minutes?: number) => void;
    onComplete: (task: Task) => void;
    onEdit: (task: Task) => void;
    onWhy: (task: Task) => void;
    onRescue: () => void;
    onMinimum: () => void;
    onAdd: () => void;
    onReplan: () => void;
}
const icons = { math: Calculator, logic: Brain, writing: PenLine, english: Sparkles };
const shortTitle = (task: Task) => task.title.replace(/ · /g, '｜');

export function Dashboard({ state, update, onPage, onStart, onComplete, onEdit, onWhy, onRescue, onMinimum, onAdd, onReplan }: Props) {
    const date = today();
    const day = state.days[date];
    const progress = completion(state, date);
    const week = weekStats(state, date);
    const latest = sortedExams(state).at(-1);
    const core = day.tasks.map(taskId => state.tasks.find(task => task.id === taskId)).filter((task): task is Task => !!task && !task.deleted);
    const next = core.find(task => !task.doneDate && task.due <= date);
    const extra = rankedTasks(state, date).filter(row => !day.tasks.includes(row.task.id));
    const left = Math.max(0, daysBetween(date, state.settings.examDate));
    const mode = { standard: '今日任务', minimum: '轻量计划', recovery: '重新开始', rescue: '剩下时间，先做这些' }[day.mode];

    return <div className="dashboard">
        <section className="mission-overview glass">
            <div className="countdown-block">
                <div className="block-label"><CalendarDays size={18}/>距离初试</div>
                <div className="countdown-value">{left}<span>天</span></div>
                <button className="text-button" onClick={() => onPage('settings')}>考试 {state.settings.examDate.replaceAll('-','.')}<Pencil size={13}/></button>
            </div>
            <div className="overview-divider"/>
            <div className="score-block">
                <div className="block-label"><Target size={18}/>目标分数</div>
                <div className="score-value">{state.settings.target}<span>/ 300</span></div>
                <div className="progress"><i style={{width:`${Math.min(100,(latest?.total??0)/state.settings.target*100)}%`}}/></div>
                <div className="score-meta"><span>最近 {latest?.total??'—'}</span><span>{latest?`还差 ${Math.max(0,state.settings.target-latest.total)} 分`:'等待首次模考'}</span></div>
            </div>
            <div className="today-orbit">
                <div className="orbit-ring" style={{'--completion': `${progress.rate}%`} as React.CSSProperties}><div><b>{progress.done}<small>/{progress.total}</small></b><span>今日完成</span></div></div>
                <span className="orbit-caption">{progress.rate===100&&progress.total?'今天的三步，稳稳拿下':'每完成一步，就近一点'}</span>
            </div>
        </section>

        <div className="target-strip">{Object.entries(subjects).map(([subject,label]) => <span key={subject}>{label}<b>{state.settings.targets[subject as Subject]}</b><small>/ {maxima[subject as Subject]}</small></span>)}</div>

        <div className="section-title task-section-title"><div className="heading-with-icon"><span className="section-icon"><Layers3 size={19}/></span><h2>{mode}</h2><span className="task-count">{progress.done}/{progress.total}</span></div><button className="text-button" onClick={()=>onPage('plan')}>编辑计划 <ArrowRight size={16}/></button></div>
        <div className="tasks">{core.map((task,index)=>{
            const Icon=icons[task.subject];
            const done=task.doneDate===date;
            return <article className={'task glass task-'+task.subject+(done?' completed':'')} key={task.id}>
                <div className="task-top"><span className={'task-symbol '+task.subject}><Icon size={23}/></span><span className="task-step">{done?<CheckCircle2 size={22}/>:<><span>STEP</span> {String(index+1).padStart(2,'0')}</>}</span></div>
                <div className="task-subject">{subjects[task.subject]}<span>{task.subject==='math'?'重点补强':task.subject==='logic'?'推理强化':task.subject==='writing'?'每天动笔':'保持手感'}</span></div>
                <h3>{shortTitle(task)}</h3>
                <div className="task-details"><span><Clock3 size={15}/>{day.limits[task.id]??task.minutes} 分钟</span><button className="why" onClick={()=>onWhy(task)}><HelpCircle size={15}/>安排理由</button></div>
                <button className={'task-start '+(done?'done':'')} onClick={()=>done?onComplete(task):onStart(task)}>{done?<><CheckCircle2 size={18}/>已完成 · 撤销</>:<><Play size={17} fill="currentColor"/>开始学习<ArrowRight size={17}/></>}</button>
                <div className="task-tools"><button onClick={()=>onComplete(task)}><Check size={15}/>{done?'恢复任务':'标记完成'}</button><button aria-label={'编辑'+task.title} onClick={()=>onEdit(task)}><Pencil size={15}/></button></div>
            </article>;
        })}</div>
        {!core.length&&<section className="card empty"><h3>从一件小事开始。</h3><button className="primary" onClick={onAdd}><Plus size={18}/>添加任务</button><button className="secondary" onClick={onReplan}>重新安排</button></section>}
        <div className="action-row"><button className="primary large start-next" disabled={!next} onClick={()=>next&&onStart(next)}><Play size={18}/>{next?'开始第一项':'核心任务已完成'}</button><button className="rescue" aria-label="我今天拖延了，重新救一下今天" onClick={onRescue}><Flame size={19}/>时间不够？救一下今天<ChevronRight size={18}/></button></div>

        <section className="minimum glass"><div className="minimum-icon"><Sparkles size={23}/></div><div><h2>{day.mode==='minimum'&&progress.rate===100?'最低线已守住，做得好。':'状态一般？切到轻量模式'}</h2><p>数学 20 分钟 · 逻辑 20 分钟 · 写作 15 分钟</p></div><button className="secondary" onClick={onMinimum}>启用最低线 <ArrowRight size={16}/></button></section>

        <div className="two-cols lower"><section className="card glass focus-panel"><div className="panel-title"><div className="heading-with-icon"><span className="section-icon"><Target size={19}/></span><h2>重点补强</h2></div><button className="text-button" onClick={()=>onPage('map')}>备考地图 <ArrowRight size={15}/></button></div>
            <button className="focus-link" onClick={()=>onPage('math')}><span className="task-symbol math"><Calculator size={20}/></span><div><b>数学训练</b><small>二轮提高 · 限时训练 · 错题回炉</small></div><ArrowRight size={19}/></button>
            <button className="focus-link" onClick={()=>onPage('logic')}><span className="task-symbol logic"><Brain size={20}/></span><div><b>综合推理</b><small>整理条件 · 画图推理 · 限时练习</small></div><ArrowRight size={19}/></button>
            <details className="details"><summary>有余力再做 · {extra.length} 项</summary>{extra.map(({task})=><div className="simple-row" key={task.id}><span>{task.title}</span><button className="text-button" onClick={()=>onStart(task)}>开始</button></div>)}</details>
        </section><section className="card glass latest"><div className="panel-title"><div className="heading-with-icon"><span className="section-icon"><GraduationCap size={19}/></span><h2>模考成绩</h2></div><button className="text-button" onClick={()=>onPage('exams')}>录入 / 查看 <ArrowRight size={15}/></button></div><strong>{latest?.total??'—'}<small> / 300</small></strong><p>{latest?.date??'还没有模考记录'}</p><div className="score-chips">{latest?.scores?Object.entries(subjects).map(([subject,label])=><span key={subject}>{label} {latest.scores![subject as Subject]}</span>):<span>分科成绩待补充</span>}</div></section></div>

        <div className="stat-grid home-stats"><div><small>今日专注</small><strong>{formatMinutes(minutesOn(state,date))}</strong></div><div><small>本周专注</small><strong>{formatMinutes(week.minutes)}</strong></div><div><small>今日核心完成</small><strong>{progress.done} / {progress.total}<em> · {progress.rate}%</em></strong></div><div><small>本周完成率</small><strong>{week.rate}%</strong></div></div>
        <div className="two-cols"><section className="card glass"><div className="panel-title"><div className="heading-with-icon"><span className="section-icon"><Clock3 size={19}/></span><h2>学习趋势</h2></div><span className="muted">最近 7 天</span></div><TimeChart state={state} date={date}/></section><section className="card glass"><div className="panel-title"><div className="heading-with-icon"><span className="section-icon"><PenLine size={19}/></span><h2>今日复盘</h2></div><span className="muted">1 分钟就好</span></div><Review state={state} date={date} update={update}/></section></div>
    </div>;
}
