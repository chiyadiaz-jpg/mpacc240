import { useState } from 'react';
import type { State } from '../types';
import { minutesOn, weekStats, subjectTimes, completion } from '../utils/statistics';
import { today, formatMinutes } from '../utils/date';
import { subjects } from '../data/initial';
import { TimeChart, SubjectChart, ExamChart } from '../components/Charts';
export function StatsPage({ state }: {
    state: State;
}) { const [days, setDays] = useState(7); const date = today(), week = weekStats(state, date); const distribution = subjectTimes(state), total = distribution.reduce((a, x) => a + x.minutes, 0); return <><div className="stat-grid"><div className="card"><small>今日专注</small><strong className="text-stat">{formatMinutes(minutesOn(state, date))}</strong></div><div className="card"><small>本周专注</small><strong className="text-stat">{formatMinutes(week.minutes)}</strong></div><div className="card"><small>今日核心完成率</small><strong>{completion(state, date).rate}<em>%</em></strong></div><div className="card"><small>本周核心完成率</small><strong>{week.rate}<em>%</em></strong></div></div><div className="two-cols"><section className="card"><div className="panel-title"><h2>学习时间趋势</h2><div className="segmented">{[7, 30].map(n => <button key={n} className={days === n ? 'selected' : ''} onClick={() => setDays(n)}>{n} 天</button>)}</div></div><TimeChart state={state} date={date} days={days}/><small>专注计时与日历补录；缺失记录按 0 展示。</small></section><section className="card"><h2>各科学习时间</h2><SubjectChart data={distribution}/><div className="score-chips">{distribution.map(x => <span key={x.subject}>{subjects[x.subject]} {total ? Math.round(x.minutes / total * 100) : 0}%</span>)}</div></section></div><section className="card"><h2>总分向目标靠近</h2><ExamChart state={state}/><p>记录变化，不预测概率。各科趋势可在模考中心切换查看。</p></section></>; }
