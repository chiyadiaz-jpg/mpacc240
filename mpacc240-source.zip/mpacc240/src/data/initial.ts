import { applyStudyProfile } from '../services/studyProfile';
import type { State, Subject } from '../types';
import { today, addDays } from '../utils/date';
export const subjects: Record<Subject, string> = { math: '数学', logic: '逻辑', writing: '管综写作', english: '英语二' };
export const maxima: Record<Subject, number> = { math: 75, logic: 60, writing: 65, english: 100 };
export const statusOptions = ['未开始', '一轮完成', '二轮进行中', '二轮完成', '专项训练', '真题验证', '基本掌握'] as const;
export const causes = ['不会', '方法不熟', '计算错误', '审题错误', '粗心', '时间不足', '知识点遗忘', '作文问题', '其他'];
export function initialState(): State {
    const d = today();
    const state: State = { version: 1, settings: { examDate: '2026-12-19', startDate: d, target: 240, targets: { math: 57, logic: 53, writing: 45, english: 85 }, dailyMinutes: 300, weakest: 'writing', progress: { math: '二轮提高 · 当前解析几何', logic: '二轮刚开始 · 首模错 3–4 题', writing: '刚开始 · 需要高频动笔', english: '阅读十几篇 · 基础较好，作文较弱' }, theme: 'light', onboarded: false }, tasks: [
            { id: 't-writing', subject: 'writing', title: '论证有效性分析 · 识别漏洞并动笔', minutes: 45, kind: 'essay', created: d, due: d, priority: 0, debt: true, accuracy: 50, moduleId: 'w1' },
            { id: 't-logic', subject: 'logic', title: '论证逻辑 · 二轮核心模块', minutes: 70, kind: 'course', created: d, due: d, priority: 0, debt: true, accuracy: 88, moduleId: 'l2' },
            { id: 't-math', subject: 'math', title: '解析几何 · 限时专项训练', minutes: 60, kind: 'practice', created: d, due: d, priority: 0, debt: true, accuracy: 72, moduleId: 'm1' },
            { id: 't-english-essay', subject: 'english', title: '小作文 · 建立表达框架', minutes: 30, kind: 'essay', created: d, due: d, priority: 0, debt: true, accuracy: 65, moduleId: 'e2' },
            { id: 't-reading', subject: 'english', title: '真题阅读 · 保持手感', minutes: 25, kind: 'maintenance', created: d, due: d, priority: 0, debt: false, accuracy: 88, moduleId: 'e1' },
            { id: 't-word', subject: 'english', title: '单词复习 · 十分钟', minutes: 10, kind: 'maintenance', created: d, due: d, priority: -10, debt: false, accuracy: 90 }
        ], modules: [
            { id: 'm1', subject: 'math', title: '解析几何', status: '二轮进行中', course: false, practice: false, verified: false },
            { id: 'm2', subject: 'math', title: '代数与不等式', status: '二轮完成', course: true, practice: true, verified: false },
            { id: 'm3', subject: 'math', title: '排列组合与概率', status: '一轮完成', course: true, practice: false, verified: false },
            { id: 'm4', subject: 'math', title: '应用题与数据分析', status: '一轮完成', course: true, practice: false, verified: false },
            { id: 'l1', subject: 'logic', title: '形式逻辑', status: '二轮进行中', course: false, practice: false, verified: false },
            { id: 'l2', subject: 'logic', title: '论证逻辑', status: '一轮完成', course: true, practice: false, verified: false },
            { id: 'l3', subject: 'logic', title: '综合推理', status: '一轮完成', course: true, practice: false, verified: false },
            { id: 'w1', subject: 'writing', title: '论证有效性分析', status: '未开始', course: false, practice: false, verified: false },
            { id: 'w2', subject: 'writing', title: '论说文 · 审题与结构', status: '未开始', course: false, practice: false, verified: false },
            { id: 'w3', subject: 'writing', title: '素材积累与限时写作', status: '未开始', course: false, practice: false, verified: false },
            { id: 'e1', subject: 'english', title: '真题阅读', status: '专项训练', course: true, practice: true, verified: false },
            { id: 'e2', subject: 'english', title: '小作文与表达库', status: '未开始', course: false, practice: false, verified: false },
            { id: 'e3', subject: 'english', title: '大作文框架与限时训练', status: '未开始', course: false, practice: false, verified: false },
            { id: 'e4', subject: 'english', title: '翻译 · 新题型 · 完形', status: '一轮完成', course: true, practice: false, verified: false }
        ], exams: [{ id: 'first-exam', date: d, scores: null, total: 205, times: { math: 0, logic: 0, writing: 0, english: 0 }, errors: { math: 0, logic: 0, english: 0 }, reasons: [], completed: true, note: '用户提供的首次模考总分；分科成绩和日期待补充。', sample: false }], records: [{ id: 'sample-record', subject: 'math', date: d, title: '解析几何 · 圆与直线（示例）', type: '错题', minutes: 4, cause: '计算错误', review: '代入前先检查符号，三天后再练。', answer: '', structure: '', material: '', correction: '', reattempt: addDays(d, 3), mastered: false, completed: false, knew: true, careless: true, overtime: false, hesitant: false, sample: true }], sessions: [], days: {}, focus: null, phases: [{ id: 'p1', title: '二轮提高 · 欠账清零', start: d, end: addDays(d, 25), focus: '写作高频动笔，推进逻辑二轮，完成数学提高。' }, { id: 'p2', title: '专项训练 · 真题验证', start: addDays(d, 26), end: addDays(d, 55), focus: '错题回炉、限时训练、英语作文框架。' }, { id: 'p3', title: '模考 · 冲刺', start: addDays(d, 56), end: '2026-12-18', focus: '整卷模拟、时间分配与稳定性。' }] };
    return applyStudyProfile(state,d);
}
