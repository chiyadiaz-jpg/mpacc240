import type { State, Task } from '../types';
import { daysBetween } from '../utils/date';
export function rankTask(t: Task, s: State, date: string) {
    const reasons: string[] = [];
    const base = { math: 130, logic: 110, writing: 80, english: 40 };
    let score = base[t.subject] + t.priority;
    const remaining = Math.max(0, daysBetween(date, s.settings.examDate));
    if (t.subject === 'math') reasons.push('数学是当前主攻科目，优先安排训练和错题回炉。');
    if (t.subject === 'logic') reasons.push('逻辑提高权重，优先补上推理能力。');
    if (t.subject === 'logic' && (t.moduleId === 'l3' || /综合推理/.test(t.title))) {
        score += 18;
        reasons.push('综合推理是你明确指出的薄弱项，额外提高优先级。');
    }
    if (t.kind === 'essay') {
        score += t.subject === 'english' ? 29 : 15;
        reasons.push('写作需要实际动笔，避免只听课不练习。');
    }
    if (t.debt) {
        score += 12;
        reasons.push('该内容仍有欠账，优先推进关键进度。');
    }
    const wait = Math.max(0, daysBetween(t.due, date));
    score += Math.min(18, wait * 3);
    if (wait)
        reasons.push(`已延期 ${wait} 天，适度提高优先级。`);
    const recentRecords = s.records.filter(r => r.subject === t.subject && !r.sample && r.accuracy !== undefined && r.date <= date).sort((a, b) => a.date.localeCompare(b.date)).slice(-3);
    const recentAccuracy = recentRecords.length ? recentRecords.reduce((sum, r) => sum + r.accuracy!, 0) / recentRecords.length : t.accuracy;
    score += (100 - recentAccuracy) * .12;
    if (recentRecords.length && recentAccuracy < 75)
        reasons.push(`近期训练平均正确率 ${Math.round(recentAccuracy)}%，需要针对性巩固。`);
    const exams = s.exams.filter(e => e.scores).sort((a, b) => a.date.localeCompare(b.date));
    const last = exams.at(-1), prev = exams.at(-2);
    if (last?.scores) {
        const gap = s.settings.targets[t.subject] - last.scores[t.subject];
        score += Math.max(0, gap) * 1.4;
        if (gap > 0)
            reasons.push(`最近模考该科距目标还有 ${gap} 分。`);
        if (prev?.scores && prev.scores[t.subject] > last.scores[t.subject] + 3) {
            score += 16;
            reasons.push('最近模考该科退步，需要及时回炉。');
        }
    }
    const mod = s.modules.find(m => m.id === t.moduleId);
    if (mod) {
        const mastery = (Number(mod.course) + Number(mod.practice) + Number(mod.verified)) / 3;
        score += (1 - mastery) * 8;
        if (mod.verified && mod.practice && mod.course)
            score -= 24;
    }
    const phase = s.phases.find(p => p.start <= date && p.end >= date);
    if (phase && /真题|冲刺|模考/.test(phase.title) && ['practice', 'review', 'essay'].includes(t.kind)) {
        score += 10;
        reasons.push('当前阶段更重视训练与验证。');
    }
    if (remaining < 40) {
        score += ['practice', 'review', 'essay'].includes(t.kind) ? 14 : -8;
        if (t.kind === 'maintenance')
            score -= 8;
        reasons.push('临近考试，优先保留能转化为得分的训练。');
    }
    if (t.subject === s.settings.weakest) {
        score += 5;
        reasons.push('这是你目前标记的薄弱科目。');
    }
    score -= t.minutes * .025;
    if (!reasons.length)
        reasons.push(t.subject === 'english' ? '英语基础较好，安排轻量训练保持手感。' : '推进当前阶段的核心模块。');
    return { task: t, score: Math.round(score), reasons };
}
export const rankedTasks = (s: State, date: string) => s.tasks.filter(t => !t.deleted && !t.doneDate && t.due <= date).map(t => rankTask(t, s, date)).sort((a, b) => b.score - a.score || a.task.id.localeCompare(b.task.id));
