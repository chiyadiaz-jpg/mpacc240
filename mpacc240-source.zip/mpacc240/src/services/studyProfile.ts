import type { State, Task } from '../types';
import { makeDay } from './planner';

/** Apply the requested emphasis once, without losing records or manual task edits. */
export function applyStudyProfile(state: State, date: string): State {
    if (state.settings.studyProfile === 'math-logic-v2') return state;
    const tasks = [...state.tasks];
    const hasComposite = tasks.some(t => !t.deleted && !t.doneDate && t.subject === 'logic' && (t.moduleId === 'l3' || /综合推理/.test(t.title)));
    if (tasks.length && !hasComposite && !tasks.some(t => t.id === 'focus-composite-v2')) {
        const task: Task = { id: 'focus-composite-v2', title: '综合推理 · 条件整理与限时训练', subject: 'logic', minutes: 60, created: date, due: date, priority: 0, kind: 'practice', moduleId: 'l3', debt: true, accuracy: 70 };
        tasks.push(task);
    }
    const next: State = {
        ...state,
        tasks,
        settings: { ...state.settings, studyProfile: 'math-logic-v2', weakest: 'math', progress: {
            ...state.settings.progress,
            math: state.settings.progress.math === '二轮提高 · 当前解析几何' ? '二轮提高 · 数学重点补强' : state.settings.progress.math,
            logic: state.settings.progress.logic === '二轮刚开始 · 首模错 3–4 题' ? '二轮推进 · 综合推理重点补强' : state.settings.progress.logic,
        } },
    };
    const current = state.days[date];
    if (current && current.mode === 'standard' && !state.focus) {
        const completed = current.tasks.filter(taskId => tasks.find(t => t.id === taskId)?.doneDate === date);
        const plan = makeDay(next, date);
        next.days = { ...state.days, [date]: { ...plan, review: current.review, tasks: [...completed, ...plan.tasks].slice(0, 3) } };
    }
    return next;
}
