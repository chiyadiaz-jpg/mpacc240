import type { State, Day } from '../types';
import { addDays } from '../utils/date';
import { rankedTasks, rankTask } from './priority';
export const emptyReview = () => ({ done: '', undone: '', problem: '', next: '' });
export function makeDay(s: State, date: string): Day {
    let misses = 0;
    for (let i = 1; i <= 3; i++) {
        const previous = s.days[addDays(date, -i)];
        if (previous && previous.tasks.length && !previous.tasks.some(id => s.tasks.find(t => t.id === id)?.doneDate === addDays(date, -i)))
            misses++;
        else
            break;
    }
    const recovery = misses >= 2;
    const budget = recovery ? Math.min(s.settings.dailyMinutes, 90) : s.settings.dailyMinutes;
    const count = recovery ? 2 : 3;
    let used = 0;
    const limits: Record<string,number> = {};
    const chosen: ReturnType<typeof rankedTasks> = [];
    for (const row of rankedTasks(s, date)) {
        if (chosen.length >= count)
            break;
        const duration = recovery ? Math.min(row.task.minutes,row.task.kind==='essay'?30:25) : row.task.minutes;
        if (used + duration > budget)
            continue;
        if (chosen.some(r => r.task.subject === row.task.subject) && row.task.priority < 60)
            continue;
        chosen.push(row);
        used += duration;
        if (recovery) limits[row.task.id]=duration;
    }
    for (const row of rankedTasks(s, date)) {
        if (chosen.length >= count) break;
        const duration = recovery ? Math.min(row.task.minutes,row.task.kind==='essay'?30:25) : row.task.minutes;
        if (chosen.some(r => r.task.id === row.task.id) || used + duration > budget) continue;
        chosen.push(row);
        used += duration;
        if (recovery) limits[row.task.id]=duration;
    }
    return { tasks: chosen.map(r => r.task.id), mode: recovery ? 'recovery' : 'standard', limits, budget, review: emptyReview() };
}
export function ensureDay(s: State, date: string): State {
    if (s.days[date])
        return s;
    const templates = new Map<string, State['tasks'][number]>();
    for (const t of s.tasks) {
        if ((t.kind === 'maintenance' || t.kind === 'essay') && !t.deleted && t.doneDate && t.doneDate < date)
            templates.set(t.id.split('@')[0], t);
    }
    const tasks = [...templates.entries()].filter(([base]) => !s.tasks.some(t => t.id.split('@')[0] === base && !t.deleted && !t.doneDate)).map(([base, t]) => ({ ...t, id: `${base}@${date}`, created: date, due: date, doneDate: undefined })).filter(t => !s.tasks.some(x => x.id === t.id));
    const next = { ...s, tasks: [...s.tasks, ...tasks] };
    const composite = s.modules.find(module => module.id === 'l3' || (module.subject === 'logic' && /综合推理/.test(module.title)));
    if (s.tasks.length && s.settings.studyProfile === 'math-logic-v2' && composite && !(composite.course && composite.practice && composite.verified) && !next.tasks.some(task => !task.deleted && !task.doneDate && task.subject === 'logic' && (task.moduleId === composite.id || /综合推理/.test(task.title)))) {
        const taskId = `composite-practice@${date}`;
        if (!next.tasks.some(task => task.id === taskId)) next.tasks.push({ id: taskId, title: '综合推理 · 条件整理与限时训练', subject: 'logic', minutes: 60, created: date, due: date, priority: 0, kind: 'practice', moduleId: composite.id, debt: true, accuracy: 70 });
    }
    if (s.tasks.length) {
        for (const subject of ['writing', 'logic', 'math', 'english'] as const) {
            if (next.tasks.some(t => t.subject === subject && !t.doneDate && !t.deleted))
                continue;
            const eligible = s.modules.filter(m => m.subject === subject && !(m.course && m.practice && m.verified));
            const mod = subject === 'logic' ? eligible.find(m => m.id === 'l3' || /综合推理/.test(m.title)) ?? eligible[0] : eligible[0];
            if (!mod)
                continue;
            const taskId = `module-${mod.id}@${date}`;
            if (next.tasks.some(t => t.id === taskId))
                continue;
            next.tasks.push({ id: taskId, title: `${mod.title} · ${subject === 'writing' ? '动笔训练' : subject === 'logic' && !mod.course ? '二轮推进与练习' : '限时训练与回炉'}`, subject, minutes: subject === 'writing' ? 45 : subject === 'english' ? 25 : 60, created: date, due: date, priority: 0, kind: subject === 'writing' ? 'essay' : subject === 'logic' && !mod.course ? 'course' : 'practice', moduleId: mod.id, debt: true, accuracy: 70 });
        }
    }
    return { ...next, days: { ...next.days, [date]: makeDay(next, date) } };
}
export function minimumDay(s: State, date: string): Day {
    const base = s.days[date] ?? makeDay(s, date);
    const completed = s.tasks.filter(task=>!task.deleted && task.doneDate===date).map(task=>rankTask(task,s,date));
    const candidates = [...completed, ...rankedTasks(s,date)];
    const chosen = ['math','logic','writing'].map(subject=>candidates.find(row=>row.task.subject===subject)).filter(row=>!!row);
    const limits: Record<string,number> = {};
    chosen.forEach(row=>{limits[row.task.id]=Math.min(row.task.minutes,row.task.subject==='writing'?15:20);});
    return {...base,tasks:chosen.map(row=>row.task.id),limits,budget:55,mode:'minimum'};
}
export function rescueDay(s: State, date: string, from: string, until: string, energy: 'low' | 'medium' | 'high', mandatory?: string) {
    const time = (v: string) => { const [h, m] = v.split(':').map(Number); return h * 60 + m; };
    const budget = Math.max(0, time(until) - time(from));
    const usable = Math.floor(budget * ({ low: .75, medium: .9, high: 1 }[energy]));
    const ranked = rankedTasks(s, date);
    if (mandatory) {
        ranked.sort((a, b) => Number(b.task.id === mandatory) - Number(a.task.id === mandatory) || b.score - a.score);
    }
    const kept: string[] = [];
    const limits: Record<string, number> = {};
    let used = 0;
    for (const { task } of ranked) {
        if (kept.length === 3)
            break;
        const duration = energy === 'low' ? Math.min(task.minutes, task.kind === 'essay' ? 30 : 25) : task.minutes;
        if (used + duration <= usable) {
            kept.push(task.id);
            limits[task.id] = duration;
            used += duration;
        }
    }
    if (!kept.length && usable >= 10 && ranked.length) {
        kept.push(ranked[0].task.id);
        limits[ranked[0].task.id] = Math.min(10, usable);
        used = limits[ranked[0].task.id];
    }
    const day = { ...(s.days[date] ?? makeDay(s, date)), tasks: kept, limits, budget, mode: 'rescue' as const };
    const deferred = ranked.filter(r => !kept.includes(r.task.id)).map(r => ({ id: r.task.id, title: r.task.title, action: r.task.kind === 'maintenance' ? '放入碎片时间' : r.task.priority < 0 ? '延后低价值任务' : '重新评估到明天' }));
    return { day, deferred, used, budget, rest: budget - used };
}
