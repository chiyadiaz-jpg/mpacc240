import { useEffect, useState } from 'react';
import { Pause, Play, Check, ArrowLeft } from 'lucide-react';
import type { State, Focus } from '../types';
import { subjects } from '../data/initial';
export const focusSeconds = (f: Focus) => Math.min(86400, f.elapsed + (f.runningSince ? Math.max(0, (Date.now() - f.runningSince) / 1000) : 0));
export function FocusMode({ state, update, onFinish }: {
    state: State;
    update: (fn: (s: State) => State) => void;
    onFinish: (completed: boolean, seconds: number) => void;
}) {
    const f = state.focus!;
    const task = state.tasks.find(t => t.id === f.taskId)!;
    const [now, setNow] = useState(Date.now());
    const [custom, setCustom] = useState(String(f.target));
    useEffect(() => { const i = setInterval(() => setNow(Date.now()), 500); return () => clearInterval(i); }, []);
    const elapsed = focusSeconds(f), remaining = Math.max(0, f.target * 60 - elapsed);
    void now;
    const setTarget = (n: number) => { if (n >= 1 && n <= 600)
        update(s => ({ ...s, focus: s.focus ? { ...s.focus, target: n } : null })); };
    return <div className="focus-screen"><button className="back" onClick={() => onFinish(false, elapsed)}><ArrowLeft size={16}/>稍后继续</button><div className="eyebrow">ONE THING AT A TIME</div><span className={'subject ' + task.subject}>{subjects[task.subject]}</span><h1>{task.title}</h1><p>预计 {task.minutes} 分钟。现在，只做这一件事。</p><div className="timer" role="timer" aria-label="剩余时间">{String(Math.floor(remaining / 60)).padStart(2, '0')}<span>:</span>{String(Math.floor(remaining % 60)).padStart(2, '0')}</div><p>{remaining === 0 ? '这一段专注已结束，可以完成，也可以继续。' : f.runningSince ? '专注中 · 计时会在刷新后继续' : '已暂停 · 随时回来'}</p><div className="preset">{[25, 45, 60].map(n => <button className={f.target === n ? 'selected' : ''} key={n} onClick={() => setTarget(n)}>{n} 分钟</button>)}<label>自定义<input aria-label="自定义分钟" type="number" min={1} max={600} value={custom} onChange={e => setCustom(e.target.value)} onBlur={() => setTarget(Number(custom))}/></label></div><div className="focus-actions"><button className="secondary" onClick={() => update(s => ({ ...s, focus: s.focus ? { ...s.focus, elapsed: focusSeconds(s.focus), runningSince: s.focus.runningSince ? null : Date.now() } : null }))}>{f.runningSince ? <Pause size={16}/> : <Play size={16}/>} {f.runningSince ? '暂停' : '继续'}</button><button className="primary large" onClick={() => onFinish(true, elapsed)}><Check size={18}/>完成这项任务</button></div><small>你的专注时间会自动记录。任务可以继续，休息也算数。</small></div>;
}
