import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, ReferenceLine, Legend, BarChart, Bar } from 'recharts';
import type { State, Subject } from '../types';
import { timeSeries, sortedExams } from '../utils/statistics';
import { subjects } from '../data/initial';
export function TimeChart({ state, date, days = 7 }: {
    state: State;
    date: string;
    days?: number;
}) { return <div className="chart"><ResponsiveContainer width="100%" height={210}><AreaChart data={timeSeries(state, date, days)} margin={{ top: 15, right: 15, bottom: 0, left: -15 }}><defs><linearGradient id="timefill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4386ee" stopOpacity={.25}/><stop offset="100%" stopColor="#4386ee" stopOpacity={0}/></linearGradient></defs><CartesianGrid vertical={false} stroke="var(--border)"/><XAxis dataKey="label" tick={{ fontSize: 12, fill: 'var(--muted)' }} axisLine={false} tickLine={false}/><YAxis tick={{ fontSize: 12, fill: 'var(--muted)' }} axisLine={false} tickLine={false}/><Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8 }} formatter={v => [`${v} 分钟`, '学习时间']}/><Area type="monotone" dataKey="minutes" stroke="#4386ee" fill="url(#timefill)" strokeWidth={2}/></AreaChart></ResponsiveContainer></div>; }
export function ExamChart({ state, metric = 'total' }: {
    state: State;
    metric?: 'total' | Subject;
}) { const data = sortedExams(state).map(e => ({ date: e.date.slice(5), total: e.total, ...e.scores })); return <div className="chart"><ResponsiveContainer width="100%" height={260}><LineChart data={data} margin={{ top: 20, right: 30, left: -15, bottom: 10 }}><CartesianGrid vertical={false} stroke="var(--border)"/><XAxis dataKey="date" tick={{ fontSize: 12, fill: 'var(--muted)' }} tickLine={false} axisLine={false}/><YAxis domain={metric === 'total' ? [0, 300] : [0, 100]} tick={{ fontSize: 12, fill: 'var(--muted)' }} tickLine={false} axisLine={false}/><Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8 }}/><ReferenceLine y={metric === 'total' ? state.settings.target : state.settings.targets[metric]} stroke="#b49b70" strokeDasharray="4 4" label={{ value: '目标', fill: '#a58a60', fontSize: 12 }}/><Legend formatter={() => metric === 'total' ? '总分' : subjects[metric]}/><Line connectNulls={false} dataKey={metric} stroke="#3979e8" strokeWidth={2} dot={{ r: 4 }}/></LineChart></ResponsiveContainer></div>; }
export function SubjectChart({ data }: {
    data: {
        subject: Subject;
        minutes: number;
    }[];
}) { return <ResponsiveContainer width="100%" height={230}><BarChart data={data.map(x => ({ ...x, name: subjects[x.subject] }))} margin={{ top: 15, right: 15, left: -15, bottom: 0 }}><CartesianGrid vertical={false} stroke="var(--border)"/><XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--muted)' }}/><YAxis tick={{ fontSize: 12, fill: 'var(--muted)' }}/><Tooltip /><Bar name="学习分钟" dataKey="minutes" fill="#74a6f4" radius={[5, 5, 0, 0]}/></BarChart></ResponsiveContainer>; }
