import { useEffect } from 'react';
import { Sparkles, ArrowRight, X } from 'lucide-react';
import type { Subject } from '../types';
const messages: Record<Subject, string[]> = {
    math: ['又拿下一步，数学正在变得更稳。', '今天练过的题，正在变成你的底气。', '漂亮！让难题少一题，让信心多一点。'],
    logic: ['一条推理理顺了，下一次就更从容。', '综合推理，一步一步拆开就会清楚。', '这一步很值，逻辑手感又回来一点。'],
    writing: ['真正动笔了，这就是进步。', '又写下一篇，表达正在慢慢成形。'],
    english: ['手感保持住了，稳稳向前。', '今天的积累，下次就能用上。'],
};
export function Celebration({ subject, count, next, onNext, onClose }: { subject: Subject; count: number; next: boolean; onNext: () => void; onClose: () => void }) {
    useEffect(() => { const timer = setTimeout(onClose, 8000); return () => clearTimeout(timer); }, [onClose]);
    const options = messages[subject];
    return <section className="celebration" role="status" aria-live="polite">
        <div className="celebrate-icon"><Sparkles size={28}/>{[0,1,2,3,4,5].map(n=><i key={n} style={{'--particle':n} as React.CSSProperties}/>)}</div>
        <button className="celebrate-close" aria-label="关闭鼓励提示" onClick={onClose}><X size={17}/></button>
        <div><strong>{next ? '这一项，拿下了！' : '今天的核心任务，完成！'}</strong><p>{options[(count-1)%options.length]}</p></div>
        <button className="text-button" onClick={next ? onNext : onClose}>{next ? '继续下一项' : '好好休息一下'}<ArrowRight size={16}/></button>
    </section>;
}
