export const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
// Date-only arithmetic uses UTC midnight to avoid crossing a calendar day.
export const dateMs = (s: string) => Date.parse(s + 'T00:00:00Z');
export const daysBetween = (a: string, b: string) => Math.round((dateMs(b) - dateMs(a)) / 86400000);
export const addDays = (s: string, n: number) => new Date(dateMs(s) + n * 86400000).toISOString().slice(0, 10);
export const weekStart = (s: string) => addDays(s, -((new Date(dateMs(s)).getUTCDay() + 6) % 7));
// LAN HTTP addresses are not secure contexts, so randomUUID may be absent.
export const id = () => {
    if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = [...bytes].map(n => n.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
};
export const formatMinutes = (n: number) => n >= 60 ? `${Math.floor(n / 60)} 小时 ${Math.round(n % 60)} 分` : `${Math.round(n)} 分钟`;
export const prettyDate = (s: string) => new Date(dateMs(s)).toLocaleDateString('zh-CN', { timeZone: 'Asia/Shanghai', month: 'long', day: 'numeric', weekday: 'long' });
