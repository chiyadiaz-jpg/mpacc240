import type { State, Subject } from '../types';
import { addDays, weekStart } from './date';
export const minutesOn = (s: State, d: string) => s.sessions.filter(x => x.date === d).reduce((a, x) => a + x.seconds / 60, 0);
export function completion(s: State, d: string) { const ids = s.days[d]?.tasks ?? []; const done = ids.filter(id => s.tasks.find(t => t.id === id)?.doneDate === d).length; return { done, total: ids.length, rate: ids.length ? Math.round(done / ids.length * 100) : 0 }; }
export const timeSeries = (s: State, d: string, n: number) => Array.from({ length: n }, (_, i) => { const date = addDays(d, i - n + 1); return { date, label: date.slice(5), minutes: Math.round(minutesOn(s, date)) }; });
export function weekStats(s: State, d: string) { const start = weekStart(d); let minutes = 0, total = 0, done = 0; for (let i = 0; i < 7; i++) {
    const date = addDays(start, i);
    if (date > d)
        break;
    minutes += minutesOn(s, date);
    const c = completion(s, date);
    total += c.total;
    done += c.done;
} return { minutes, total, done, rate: total ? Math.round(done / total * 100) : 0 }; }
export const subjectTimes = (s: State) => Object.entries({ math: 0, logic: 0, writing: 0, english: 0 }).map(([subject]) => ({ subject: subject as Subject, minutes: Math.round(s.sessions.filter(x => x.subject === subject).reduce((n, x) => n + x.seconds / 60, 0)) }));
export const sortedExams = (s: State) => [...s.exams].sort((a, b) => a.date.localeCompare(b.date) || s.exams.indexOf(a) - s.exams.indexOf(b));
