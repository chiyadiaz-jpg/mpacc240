import { useEffect, useState, useCallback } from 'react';
import { ArrowUpRight, LayoutDashboard, BookOpen, Target, CalendarDays, ChartNoAxesCombined, Settings, Play, Flame, Check, ChevronRight, Plus, GraduationCap, PenLine, Languages, Brain, Calculator, CheckCircle2, Clock3, Sun, Moon, Pencil, Trash2, HelpCircle, ArrowRight, RotateCcw, Sparkles } from 'lucide-react';
import type { State, Task, Subject } from './types';
import { subjects, maxima } from './data/initial';
import { useStore } from './hooks/useStore';
import { today, daysBetween, formatMinutes, prettyDate, id, addDays } from './utils/date';
import { completion, minutesOn, weekStats, sortedExams } from './utils/statistics';
import { rankedTasks, rankTask } from './services/priority';
import { makeDay, minimumDay, rescueDay } from './services/planner';
import { Modal } from './components/Modal';
import { TaskEditor } from './components/TaskEditor';
import { FocusMode } from './components/FocusMode';
import { Rescue } from './components/Rescue';
import { TimeChart } from './components/Charts';
import { SettingsPage, SettingsForm } from './pages/SettingsPage';
import { MapPage } from './pages/MapPage';
import { ExamsPage } from './pages/ExamsPage';
import { RecordsPage } from './pages/RecordsPage';
import { CalendarPage, Review } from './pages/CalendarPage';
import { StatsPage } from './pages/StatsPage';
import { Dashboard } from './pages/Dashboard';
import { Celebration } from './components/Celebration';
type Page = 'home' | 'plan' | 'map' | 'math' | 'logic' | 'writing' | 'english' | 'exams' | 'errors' | 'calendar' | 'stats' | 'settings';
const navigation: {
    page: Page;
    label: string;
    icon: typeof Target;
    group?: string;
}[] = [{ page: 'home', label: '作战室', icon: LayoutDashboard }, { page: 'plan', label: '今日计划', icon: Target }, { page: 'map', label: '备考地图', icon: BookOpen }, { page: 'math', label: '数学', icon: Calculator, group: '分科训练' }, { page: 'logic', label: '逻辑', icon: Brain }, { page: 'writing', label: '写作', icon: PenLine }, { page: 'english', label: '英语二', icon: Languages }, { page: 'exams', label: '模考中心', icon: GraduationCap, group: '观察与复盘' }, { page: 'errors', label: '错题本', icon: BookOpen }, { page: 'calendar', label: '学习日历', icon: CalendarDays }, { page: 'stats', label: '数据统计', icon: ChartNoAxesCombined }, { page: 'settings', label: '设置与备份', icon: Settings }];
export default function App() {
    const { state, update, restore, error, saved, blocked } = useStore();
    const [page, setPage] = useState<Page>('home');
    const [editor, setEditor] = useState<Task | 'new' | null>(null);
    const [rescue, setRescue] = useState(false);
    const [why, setWhy] = useState<Task | null>(null);
    const [remove, setRemove] = useState<Task | null>(null);
    const [message, setMessage] = useState('');
    const [celebration, setCelebration] = useState<{subject: Subject; count: number}|null>(null);
    const dismissCelebration=useCallback(()=>setCelebration(null),[]);
    const [taskFilter, setTaskFilter] = useState<'active' | 'done' | 'future'>('active');
    const date = today(), day = state.days[date]!;
    const notify = (m: string) => setMessage(m);
    useEffect(() => { document.documentElement.dataset.theme = state.settings.theme; }, [state.settings.theme]);
    useEffect(() => { if (message) {
        const i = setTimeout(() => setMessage(''), 4000);
        return () => clearTimeout(i);
    } }, [message]);
    useEffect(() => { const modelContext = (document as unknown as {
        modelContext?: {
            registerTool: (tool: unknown, options: unknown) => Promise<void>;
        };
    }).modelContext; if (!modelContext)
        return; const life = new AbortController(); void Promise.resolve(modelContext.registerTool({ name: 'read_current_study_plan', description: 'Read the current core study tasks and their durations without changing data.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true }, execute: () => ({ date, mode: day.mode, tasks: day.tasks.map(taskId => { const t = state.tasks.find(t => t.id === taskId); return t ? { title: t.title, minutes: day.limits[t.id] ?? t.minutes, completed: t.doneDate === date } : null; }).filter(Boolean) }) }, { signal: life.signal })).catch(() => { }); return () => life.abort(); }, [state, date, day]);
    const start = (t: Task, minutes?: number) => { if (state.focus && state.focus.taskId !== t.id) {
        notify('先完成或结束当前专注，再开始新任务。');
        return;
    } update(s => ({ ...s, focus: s.focus ?? { taskId: t.id, target: minutes ?? s.days[date]?.limits[t.id] ?? t.minutes, elapsed: 0, runningSince: Date.now() } })); };
    const finish = (completed: boolean, seconds: number) => { update(s => { const t = s.tasks.find(t => t.id === s.focus?.taskId); if (!t)
        return { ...s, focus: null }; return { ...s, focus: null, tasks: s.tasks.map(x => x.id === t.id && completed ? { ...x, doneDate: date } : x), sessions: seconds > 0 ? [...s.sessions, { id: id(), taskId: t.id, title: t.title, subject: t.subject, date, seconds: Math.round(seconds), completed }] : s.sessions }; }); if(completed){const task=state.tasks.find(t=>t.id===state.focus?.taskId);if(task)setCelebration({subject:task.subject,count:state.tasks.filter(t=>t.doneDate===date).length+1});}else notify('专注时间已保存，稍后继续。'); };
    const complete = (t: Task) => { update(s => ({ ...s, tasks: s.tasks.map(x => x.id === t.id ? { ...x, doneDate: x.doneDate ? undefined : date } : x) })); if(t.doneDate){setCelebration(null);notify('已恢复为未完成');}else{setMessage('');setCelebration({subject:t.subject,count:state.tasks.filter(task=>task.doneDate===date).length+1});} };
    const saveTask = (t: Task) => { update(s => { const next = { ...s, tasks: s.tasks.some(x => x.id === t.id) ? s.tasks.map(x => x.id === t.id ? t : x) : [...s.tasks, t] }; if (t.due <= date && !day.tasks.length)
        next.days = { ...next.days, [date]: makeDay(next, date) }; return next; }); notify('任务已保存'); };
    const recalc = () => { update(s => { const completed = day.tasks.filter(taskId => s.tasks.find(t => t.id === taskId)?.doneDate === date); const plan = makeDay(s, date); return { ...s, days: { ...s.days, [date]: { ...plan, tasks: [...completed, ...plan.tasks].slice(0, 3), review: day.review } } }; }); notify('已按当前进度重新评估，核心任务仍最多三项'); };
    const changeDue = (t: Task, due: string) => update(s => ({ ...s, tasks: s.tasks.map(x => x.id === t.id ? { ...x, due } : x), days: { ...s.days, [date]: { ...day, tasks: day.tasks.filter(taskId => taskId !== t.id) } } }));
    const applyRescue = (result: ReturnType<typeof rescueDay>, begin: boolean) => { update(s => ({ ...s, days: { ...s.days, [date]: result.day }, tasks: s.tasks.map(t => result.deferred.some(x => x.id === t.id) && t.kind !== 'maintenance' ? { ...t, due: addDays(date, 1) } : t) })); setRescue(false); if (begin) {
        const task = state.tasks.find(t => t.id === result.day.tasks[0]);
        if (task)
            start(task, result.day.limits[task.id]);
    } notify('新计划已应用，低价值任务已延后'); };
    const c = completion(state, date), week = weekStats(state, date), latest = sortedExams(state).at(-1);
    const core = day.tasks.map(taskId => state.tasks.find(t => t.id === taskId)).filter((x): x is Task => !!x && !x.deleted);
    const remaining = core.filter(t => !t.doneDate && t.due <= date);
    const extra = rankedTasks(state, date).filter(r => !day.tasks.includes(r.task.id));
    if (state.focus && state.tasks.some(t => t.id === state.focus?.taskId))
        return <FocusMode state={state} update={update} onFinish={finish}/>;
    return <div className="shell"><aside><div className="brand"><b><Sparkles size={24}/></b><div>MPAcc 240<small>个人学习空间</small></div></div><nav aria-label="主导航"><div className="nav-label">学习工作台</div>{navigation.map(({ page: p, label, icon: Icon, group }) => <div key={p}>{group && <div className="nav-label group-label">{group}</div>}<button title={label} className={'nav ' + (page === p ? 'active' : '')} onClick={() => setPage(p)}><Icon size={17}/><span>{label}</span>{page === p && <i />}</button></div>)}</nav><div className="sidebar-bottom"><span className="storage-dot"/>{saved && !blocked ? '已保存在此浏览器' : '存储需要处理'}<small>每一步，都算数。</small></div></aside><main><header><span>我的工作台 <ChevronRight size={14}/> {navigation.find(n => n.page === page)?.label}</span><div className="header-right"><span>{prettyDate(date)}</span><button aria-label="切换深色模式" onClick={() => update(s => ({ ...s, settings: { ...s.settings, theme: s.settings.theme === 'light' ? 'dark' : 'light' } }))}>{state.settings.theme === 'light' ? <Moon size={17}/> : <Sun size={17}/>}</button></div></header>{error && <div className="warning banner">{error}<button className="text-button" onClick={() => setPage('settings')}>处理存档 →</button></div>}<div className="page-heading"><div className="eyebrow">{page === 'home' ? '数学主攻 · 综合推理补强' : ''}</div><h1>{page === 'home' ? (c.total===3?'今天，拿下这三步。':c.total>0?`今天，先做好这 ${c.total} 件事。`:'今天，从一小步开始。') : navigation.find(n => n.page === page)?.label}</h1><p>{({home:'',plan:'安排任务 · 立即开始',map:'查看进度 · 补齐欠账',math:'专项训练 · 错题回炉',logic:'综合推理 · 限时练习',writing:'动笔训练 · 批改复盘',english:'真题阅读 · 作文练习',exams:'录入成绩 · 找到失分',errors:'记录错题 · 安排复练',calendar:'查看学习 · 补录记录',stats:'专注时间 · 成绩趋势',settings:'个人目标 · 数据备份'})[page]}</p></div>
    {page === 'home' && <Dashboard state={state} update={update} onPage={setPage} onStart={start} onComplete={complete} onEdit={setEditor} onWhy={setWhy} onRescue={()=>setRescue(true)} onMinimum={()=>{update(s=>({...s,days:{...s.days,[date]:minimumDay(s,date)}}));notify('已切换轻量计划');}} onAdd={()=>setEditor('new')} onReplan={recalc}/>}
    {page === 'plan' && <><div className="toolbar"><div className="tabs">{[['active', '待推进'], ['future', '延期 / 未来'], ['done', '已完成']].map(([v, l]) => <button key={v} className={taskFilter === v ? 'selected' : ''} onClick={() => setTaskFilter(v as typeof taskFilter)}>{l}</button>)}</div><div className="toolbar-buttons"><button className="secondary" onClick={recalc}><RotateCcw size={14}/>重新安排</button><button className="primary" onClick={() => setEditor('new')}><Plus size={14}/>添加任务</button></div></div><section className="card"><div className="panel-title"><h2>核心计划 · {c.done}/{c.total} 已完成</h2><small>今日预算 {day.budget} 分钟</small></div><p>数学与综合推理优先，核心任务最多三项。</p><div className="progress"><i style={{ width: `${c.rate}%` }}/></div></section><div className="plan-list">{state.tasks.filter(t => !t.deleted && (taskFilter === 'done' ? !!t.doneDate : !t.doneDate && (taskFilter === 'future' ? t.due > date : t.due <= date))).sort((a, b) => rankTask(b, state, date).score - rankTask(a, state, date).score).map(t => <article className="card plan-row" key={t.id}><span className={'subject ' + t.subject}>{subjects[t.subject]}</span><div className="plan-info"><h3>{t.title}</h3><small>{t.minutes} 分钟 · {t.due} · 优先级 {rankTask(t, state, date).score} {day.tasks.includes(t.id) ? '· 今日核心' : ''}</small></div><div className="row-actions"><button aria-label={'查看安排理由' + t.title} onClick={() => setWhy(t)}><HelpCircle size={16}/></button>{!t.doneDate && <button className="secondary" onClick={() => start(t)}><Play size={13}/>开始</button>}<button aria-label={'编辑' + t.title} onClick={() => setEditor(t)}><Pencil size={15}/></button><button aria-label={'完成' + t.title} onClick={() => complete(t)}><CheckCircle2 size={17}/></button><button aria-label={'删除' + t.title} onClick={() => setRemove(t)}><Trash2 size={15}/></button></div>{!t.doneDate && <div className="plan-secondary"><button onClick={() => changeDue(t, addDays(date, 1))}>延期到明天</button><button onClick={() => { changeDue(t, date); update(s => ({ ...s, days: { ...s.days, [date]: { ...s.days[date], tasks: [t.id, ...s.days[date].tasks.filter(x => x !== t.id)].slice(0, 3) } } })); notify('已提前为今日核心'); }}>提前到今日核心</button><button onClick={() => start(t, 10)}>只做 10 分钟</button></div>}</article>)}</div><section className="card"><h2>今天的轻量复盘</h2><Review state={state} date={date} update={update}/></section></>}
    {page === 'map' && <MapPage state={state} update={update} addTask={(subject, moduleId, title) => setEditor({ id: id(), subject, moduleId, title, minutes: subject === 'writing' ? 45 : 60, created: date, due: date, priority: 0, kind: subject === 'writing' ? 'essay' : 'practice', debt: true, accuracy: 70 })}/>}
    {(['math', 'logic', 'writing', 'english'] as Page[]).includes(page) && <RecordsPage key={page} subject={page as Subject} state={state} update={update}/>}
    {page === 'errors' && <RecordsPage state={state} update={update} errorsOnly/>}{page === 'exams' && <ExamsPage state={state} update={update}/>}{page === 'calendar' && <CalendarPage state={state} update={update}/>}{page === 'stats' && <StatsPage state={state}/>}{page === 'settings' && <SettingsPage state={state} update={update} restore={restore} notify={notify} blocked={blocked}/>}<footer>MPAcc 240 <span>已保存在此浏览器</span></footer></main>
    {editor && <TaskEditor task={editor === 'new' ? undefined : editor} state={state} onSave={saveTask} onClose={() => setEditor(null)}/>}{rescue && <Rescue state={state} onApply={applyRescue} onClose={() => setRescue(false)}/>}{why && <Modal title="为什么安排这件事？" onClose={() => setWhy(null)}><span className={'subject ' + why.subject}>{subjects[why.subject]}</span><h3>{why.title}</h3>{rankTask(why, state, date).reasons.map(r => <p key={r}>· {r}</p>)}<small>规则评分 {rankTask(why, state, date).score} · 包含时间、欠账、正确率、模考差距、阶段、掌握度和手动优先级。</small><p>这是透明的规则排程。你随时可以修改或延期。</p></Modal>}{remove && <Modal title="删除这项任务？" onClose={() => setRemove(null)}><p>{remove.title}</p><p>已有专注记录会保留，今天的计划会移除该任务。</p><div className="form-actions"><button className="secondary" onClick={() => setRemove(null)}>取消</button><button className="danger" onClick={() => { update(s => ({ ...s, tasks: s.tasks.map(t => t.id === remove.id ? { ...t, deleted: true } : t), days: { ...s.days, [date]: { ...day, tasks: day.tasks.filter(t => t !== remove.id) } } })); setRemove(null); notify('任务已删除'); }}>确认删除</button></div></Modal>}{!state.settings.onboarded && !blocked && <Modal title="欢迎来到你的 240 作战室" onClose={() => update(s => ({ ...s, settings: { ...s.settings, onboarded: true } }))} wide><div className="callout"><p>主攻数学与综合推理，保持写作和英语。首次模考：205 分。</p></div><SettingsForm value={state.settings} onboarding onSave={settings => update(s => ({ ...s, settings }))}/></Modal>}{celebration && <Celebration subject={celebration.subject} count={celebration.count} next={!!remaining.length} onClose={dismissCelebration} onNext={()=>{setCelebration(null);if(remaining[0])start(remaining[0]);}}/>}{message && <div className="toast" role="status"><CheckCircle2 size={17}/>{message}</div>}</div>;
}
